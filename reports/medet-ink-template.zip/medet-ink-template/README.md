# Beautiful HTML Penetration Testing Report Template

![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Format](https://img.shields.io/badge/Format-HTML5%20%26%20CSS3-orange.svg)
![Print](https://img.shields.io/badge/Print-Perfect%20PDF-success.svg)

Beautiful, interactive HTML penetrations and professional report templates that prints to a perfect pixel PDF.

This project provides a highly professional, easily modifiable deliverable format designed for cybersecurity consultancies, internal red teams, and enterprise security professionals. It replaces rigid legacy document formats with a modern, web-native approach that seamlessly exports to a flawless 11x8.5 landscape PDF.

## Visual Demonstration

![Report Demo](assets/demo.gif)

---

## Key Enterprise Features

- **Executive-Ready Presentation:** Designed to communicate complex security findings effectively to both technical stakeholders and executive leadership.
- **Pixel-Perfect Export:** Engineered with rigorous `@media print` CSS directives ensuring a 1:1 translation from the browser to a perfectly paginated, landscape PDF without margin degradation or layout breaks.
- **Comprehensive Template Suite:** Includes 18 pre-formatted layouts covering Executive Summaries, a Maturity Scorecard, Risk Matrices, Technical and Assessment Findings with their Evidence, Proof of Concepts, and Capability Statements.
- **Interactive Data Visualization:** Charts drawn in inline SVG with no library to load or license, plus a Chart.js radar, for dynamic presentation of metrics and maturity models.
- **Zero-Friction Deployment:** Pure HTML and CSS architecture. Requires no complex build pipelines or proprietary software to edit and deploy.

---

## Usage Instructions

1. **Get the Template:** Download [medet-ink-template.zip](reports/medet-ink-template.zip) (Download HTML on the landing page), or clone the repository.
2. **Edit the Content:** Open `combined_report.html` in your preferred code or text editor to populate your specific assessment data, client branding, and vulnerability metrics.
3. **Preview:** Open the file in a modern web browser to review the interactive layout.
4. **Generate PDF:** Use the browser's native print function (Ctrl+P / Cmd+P) and save as PDF. The document will automatically format into an 18-page, landscape executive report.

---

## Template Gallery

A selection of included page layouts:

| Cover Page | Executive Summary | Maturity Scorecard |
|:---:|:---:|:---:|
| <img src="assets/slide_01.png" width="300"/> | <img src="assets/slide_03.png" width="300"/> | <img src="assets/slide_04.png" width="300"/> |

| Technical Finding | Assessment Finding | Evidence |
|:---:|:---:|:---:|
| <img src="assets/slide_09.png" width="300"/> | <img src="assets/slide_11.png" width="300"/> | <img src="assets/slide_12.png" width="300"/> |

---:|:---:|:---:|
| <img src="assets/slide_08.png" width="300"/> | <img src="assets/slide_09.png" width="300"/> | <img src="assets/slide_12.png" width="300"/> |

---

## Contributing

We welcome contributions from the cybersecurity community. Please submit pull requests or open issues to propose new layouts, design refinements, or reporting features.

## Development and Verification

The template itself needs nothing beyond a browser. Maintainers who regenerate the combined report, the sample PDF or the gallery images, or who run the verification suite, need Python 3.9 or newer:

```sh
python3 -m pip install -r requirements-dev.txt
python3 -m playwright install chromium
python3 -m unittest discover -s tests -v
```

The suite renders every archetype and the combined report in Chromium and verifies page size, single-page printing, content overflow, chart rendering, that the combined report, sample PDF, thumbnails and demo GIF match the archetypes, consistent branding and page numbering, and links. `AGENTS.md` describes how the repository is maintained; `docs/template.md` documents the archetypes, design tokens, build pipeline and tests.
